use Amazon;

SELECT 
    Warehouse_ID,
    AVG(Processing_Time_Min) AS Avg_Processing_Time
FROM warehouses
GROUP BY Warehouse_ID
ORDER BY Avg_Processing_Time DESC
LIMIT 3;

SELECT 
    w.Warehouse_ID,
    
    COUNT(o.Order_ID) AS Total_Orders,
    
    SUM(CASE 
        WHEN o.Actual_Delivery_Date > o.Expected_Delivery_Date 
        THEN 1 ELSE 0 
    END) AS Delayed_Orders

FROM Warehouses w
LEFT JOIN Orders o 
ON w.Warehouse_ID = o.Warehouse_ID

GROUP BY w.Warehouse_ID;

WITH Global_Avg AS (
    SELECT AVG(Processing_Time_Min) AS Avg_Time
    FROM warehouses
)

SELECT 
    Warehouse_ID,
    AVG(Processing_Time_Min) AS Avg_Processing_Time
FROM warehouses
GROUP BY Warehouse_ID
HAVING AVG(Processing_Time_Min) > (
    SELECT Avg_Time FROM Global_Avg
);

SELECT 
    Warehouse_ID,
    
    (SUM(CASE 
        WHEN Actual_Delivery_Date <= Expected_Delivery_Date 
        THEN 1 ELSE 0 
    END) * 100.0 / COUNT(*)) AS On_Time_Percentage,
    
    RANK() OVER (
        ORDER BY 
        (SUM(CASE 
            WHEN Actual_Delivery_Date <= Expected_Delivery_Date 
            THEN 1 ELSE 0 
        END) * 100.0 / COUNT(*)) DESC
    ) AS Rank_Position

FROM Orders
GROUP BY Warehouse_ID;