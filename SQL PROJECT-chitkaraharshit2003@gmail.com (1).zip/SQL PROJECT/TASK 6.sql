use Amazon;

SELECT 
    Order_ID,
    Checkpoint,
    Checkpoint_Time
FROM Shipment_Tracking st
WHERE (Order_ID, Checkpoint_Time) IN (
    SELECT 
        Order_ID, 
        MAX(Checkpoint_Time)
    FROM Shipment_Tracking
    GROUP BY Order_ID
);

SELECT 
    Delay_Reason,
    COUNT(*) AS Frequency
FROM Shipment_Tracking
WHERE Delay_Reason IS NOT NULL
AND Delay_Reason != 'None'
GROUP BY Delay_Reason
ORDER BY Frequency DESC;

SELECT 
    Order_ID,
    COUNT(*) AS Delay_Count
FROM Shipment_Tracking
WHERE Delay_Reason IS NOT NULL
AND Delay_Reason != 'None'
GROUP BY Order_ID
HAVING COUNT(*) > 2;