use Amazon;

SELECT 
    r.Start_Location,
    AVG(DATEDIFF(o.Actual_Delivery_Date, o.Expected_Delivery_Date)) AS Avg_Delay_Days
FROM Orders o
JOIN Routes r 
ON o.Route_ID = r.Route_ID
GROUP BY r.Start_Location;

SELECT 
    (SUM(CASE 
        WHEN Actual_Delivery_Date <= Expected_Delivery_Date 
        THEN 1 ELSE 0 
    END) * 100.0 / COUNT(*)) AS On_Time_Delivery_Percentage
FROM Orders;

SELECT 
    Route_ID,
    AVG(Traffic_Delay_Min) AS Avg_Traffic_Delay
FROM Routes
GROUP BY Route_ID;