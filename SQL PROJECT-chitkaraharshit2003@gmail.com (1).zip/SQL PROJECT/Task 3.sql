use Amazon;

SELECT 
    r.Route_ID,
    
    AVG(DATEDIFF(o.Actual_Delivery_Date, o.Order_Date)) AS Avg_Delivery_Time_Days,
    
    AVG(r.Traffic_Delay_Min) AS Avg_Traffic_Delay,
    
    (r.Distance_KM / r.Average_Travel_Time_Min) AS Efficiency_Ratio

FROM Routes r
Inner JOIN Orders o 
ON r.Route_ID = o.Route_ID

GROUP BY 
    r.Route_ID, 
    r.Distance_KM, 
    r.Average_Travel_Time_Min;
    
SELECT 
    Route_ID,
    (Distance_KM)/(Average_Travel_Time_Min) as Efficiency_Ratio
FROM Routes 
ORDER BY Efficiency_Ratio ASC
LIMIT 3;

SELECT 
    r.Route_ID,
    r.Start_Location,
    r.End_Location,
    COUNT(*) AS total_shipments,
    SUM(CASE WHEN o.Delivery_Status = 'Delayed' THEN 1 ELSE 0 END) AS delayed_shipments,
    ROUND(100.0 * SUM(CASE WHEN o.Delivery_Status = 'Delayed' THEN 1 ELSE 0 END) / COUNT(*), 2) AS delayed_percentage
FROM Routes r
JOIN Orders o ON r.Route_ID = o.Route_ID
GROUP BY r.Route_ID, r.Start_Location, r.End_Location
HAVING delayed_percentage > 20
ORDER BY delayed_percentage DESC;

