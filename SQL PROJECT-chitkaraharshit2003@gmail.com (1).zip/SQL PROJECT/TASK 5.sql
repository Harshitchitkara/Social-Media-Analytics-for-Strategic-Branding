use Amazon;

SELECT 
    Agent_ID,
    Route_ID,
    On_Time_Percentage,
    
    RANK() OVER (
        PARTITION BY Route_ID
        ORDER BY On_Time_Percentage DESC
    ) AS Rank_Position
FROM Delivery_Agents;

SELECT 
    Agent_ID,
    On_Time_Percentage
FROM Delivery_Agents
WHERE On_Time_Percentage < 80;

SELECT 
    (SELECT AVG(Avg_Speed_KM_HR)
     FROM (
         SELECT Avg_Speed_KM_HR
         FROM Delivery_Agents
         ORDER BY On_Time_Percentage DESC
         LIMIT 5
     ) top_agents
    ) AS Top_5_Avg_Speed,
    
    (SELECT AVG(Avg_Speed_KM_HR)
     FROM (
         SELECT Avg_Speed_KM_HR
         FROM Delivery_Agents
         ORDER BY On_Time_Percentage ASC
         LIMIT 5
     ) bottom_agents
    ) AS Bottom_5_Avg_Speed;
	
    