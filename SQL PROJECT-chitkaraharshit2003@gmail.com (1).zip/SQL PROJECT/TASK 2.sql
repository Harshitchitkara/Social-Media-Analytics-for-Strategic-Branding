use Amazon;

SELECT 
    Order_ID,
    Route_ID,
    datediff(Actual_Delivery_Date, Order_Date) AS Delay_Days
FROM Orders;

SELECT 
    Route_ID,
    AVG(DATEDIFF(Actual_Delivery_Date, Order_Date)) AS Avg_Delay
FROM Orders
GROUP BY Route_ID
ORDER BY Avg_Delay DESC
LIMIT 10;

SELECT 
    Order_ID,
    Warehouse_ID,
    DATEDIFF(Actual_Delivery_Date, Order_Date) AS Delay_Days,
    RANK() OVER (
        PARTITION BY Warehouse_ID 
        ORDER BY DATEDIFF(Actual_Delivery_Date, Order_Date) DESC
    ) AS Delay_Rank
FROM Orders;