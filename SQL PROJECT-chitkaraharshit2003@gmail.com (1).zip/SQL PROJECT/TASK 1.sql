create database Amazon;
use Amazon;

SELECT Order_ID, COUNT(*)
FROM Orders
GROUP BY Order_ID
HAVING COUNT(*) > 1;

ALTER TABLE Orders
ADD PRIMARY KEY (Order_ID);

WITH avg_cte AS (
    SELECT AVG(Traffic_Delay_Min) AS avg_delay
    FROM Routes
)
UPDATE Routes
SET Traffic_Delay_Min = (SELECT avg_delay FROM avg_cte)
WHERE Traffic_Delay_Min IS NULL;

UPDATE Orders
SET Order_Date = DATE_FORMAT(Order_Date, '%Y-%m-%d'),
    Actual_Delivery_Date = DATE_FORMAT(Actual_Delivery_Date, '%Y-%m-%d');
    
SELECT *
FROM Orders
WHERE Actual_Delivery_Date < Order_Date;